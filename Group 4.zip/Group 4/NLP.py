import re
import string
import pickle
import nltk
from flask import Flask, request, jsonify, render_template
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import contractions

# Load required NLTK data
nltk.download('wordnet')
nltk.download('punkt')
nltk.download('stopwords')

# Initialize lemmatizer
lemmatizer = WordNetLemmatizer()

# Preprocess function to clean, expand contractions, and lemmatize text
def preprocess_text(text):
    # Expand contractions
    text = contractions.fix(text)
    
    # Remove words with numbers, punctuation, and lowercase the text
    text = re.sub(r"""\w*\d\w*""", ' ', text)  # Remove words with numbers
    text = re.sub('[%s]' % re.escape(string.punctuation), ' ', text.lower())  # Remove punctuation and lowercase
    
    #tokenize
    tokens = word_tokenize(text)
    
    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    tokens = [token for token in tokens if token not in stop_words]
    
    # Lemmatize the words
    lemmatized_tokens = [lemmatizer.lemmatize(token) for token in tokens]
    
    
    return ' '.join(lemmatized_tokens)

app = Flask(__name__)

# Define the filenames for saving models
VECTOR_FILE = 'vectorizer.pkl'
SVM_FILE = 'svm_model.pkl'
NB_FILE = 'naive_bayes_model.pkl'
LR_FILE = 'logistic_regression_model.pkl'
RF_FILE = 'random_forest_model.pkl'

# Function to load the vectorizer and models
def load_models():
    with open(VECTOR_FILE, 'rb') as f:
        vectorizer = pickle.load(f)

    with open(SVM_FILE, 'rb') as f:
        svm_model = pickle.load(f)

    with open(NB_FILE, 'rb') as f:
        naive_bayes_model = pickle.load(f)

    with open(LR_FILE, 'rb') as f:
        logistic_regression_model = pickle.load(f)
        
    with open(RF_FILE, 'rb') as f:
        random_forest_model = pickle.load(f)

    return vectorizer, svm_model, naive_bayes_model, logistic_regression_model, random_forest_model

# Load the models (trained or pre-trained)
vectorizer, svm_model, naive_bayes_model, logistic_regression_model, random_forest_model = load_models()

@app.route('/')
def home():
    return render_template('interface.html')

# Flask route for analyzing reviews
@app.route('/analyze', methods=['POST'])
def analyze():
    #get user input
    data = request.get_json()
    user_input = data['text']
    model_choice = data['model']

    # Preprocess the user input
    preprocessed_input = preprocess_text(user_input)
    
    # Transform the preprocessed input into vector form (numerical vector)
    features = vectorizer.transform([preprocessed_input])

    # Select the appropriate model
    if model_choice == "svm":
        model = svm_model
    elif model_choice == "naive_bayes":
        model = naive_bayes_model
    elif model_choice == "logistic_regression":
        model = logistic_regression_model
    elif model_choice == "random_forest":
        model = random_forest_model
    else:
        return jsonify({'error': 'Invalid model choice'}), 400

    # Predict the sentiment (input to `predict()` must be a vector)
    prediction = model.predict(features)[0]  # Ensure `features` is a vector
    sentiment = "Positive" if prediction == 'Positive' else "Neutral" if prediction == 'Neutral' else "Negative"

    # Add this to check preprocessing:
    print(f"Preprocessed input: {preprocessed_input}")
    print(f"Model used: {model}")
    print(f"Preprocess: {features}")
    print(f"predict: {prediction}")
    print(f"sentiment: {sentiment}")

    # Return the result
    return jsonify({
        'sentiment': sentiment,
        'model_used': model_choice
    })

if __name__ == "__main__":
    app.run(debug=True)
