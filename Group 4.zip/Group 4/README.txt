1. Instructions

Click on NLP.py to run the file, by default it will open your cmd and give you localhost link(http://127.0.0.1:5000), copy the link to our web application and paste it in google to run it



2. Libraries required 

#nltk.download('punkt')
#nltk.download('wordnet')
#nltk.download('stopwords')


3. Dataset training

If intend to train dataset or add data into dataset, straight away add into the csv file provided, after that run Amazon_Finalize.ipnyb to train the models again

